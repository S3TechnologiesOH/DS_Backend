"use strict";
/**
 * Playlist Models
 *
 * Collections of content items (customer-level).
 * Playlists can be used as widgets/layers within layouts.
 */
Object.defineProperty(exports, "__esModule", { value: true });
//# sourceMappingURL=Playlist.js.map