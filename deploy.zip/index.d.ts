/**
 * Application Entry Point
 *
 * Initializes database, Azure services, and starts Express server.
 */
export {};
//# sourceMappingURL=index.d.ts.map