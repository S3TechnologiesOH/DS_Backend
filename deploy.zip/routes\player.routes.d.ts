/**
 * Player Routes
 *
 * API endpoints for player (digital signage device) management.
 * Players are individual screens/devices at sites.
 */
declare const router: import("express-serve-static-core").Router;
export default router;
//# sourceMappingURL=player.routes.d.ts.map