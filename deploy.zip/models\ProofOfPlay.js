"use strict";
/**
 * Proof of Play Model
 *
 * Tracks when and where layouts were displayed on player devices.
 * Used for analytics and reporting.
 */
Object.defineProperty(exports, "__esModule", { value: true });
//# sourceMappingURL=ProofOfPlay.js.map