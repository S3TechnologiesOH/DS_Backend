"use strict";
/**
 * Webhook Models
 *
 * Webhooks allow real-time notifications of events to external systems.
 */
Object.defineProperty(exports, "__esModule", { value: true });
//# sourceMappingURL=Webhook.js.map