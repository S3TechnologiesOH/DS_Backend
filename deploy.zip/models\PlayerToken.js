"use strict";
/**
 * PlayerToken Model
 *
 * Represents refresh tokens for player device authentication.
 */
Object.defineProperty(exports, "__esModule", { value: true });
//# sourceMappingURL=PlayerToken.js.map