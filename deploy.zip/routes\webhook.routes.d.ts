/**
 * Webhook Routes
 *
 * @swagger
 * tags:
 *   name: Webhooks
 *   description: Webhook management and event delivery endpoints
 */
declare const router: import("express-serve-static-core").Router;
export default router;
//# sourceMappingURL=webhook.routes.d.ts.map