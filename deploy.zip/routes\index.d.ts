/**
 * Routes Index
 *
 * Central export point for all API routes.
 * Import this in app.ts to wire up all endpoints.
 */
declare const router: import("express-serve-static-core").Router;
export default router;
//# sourceMappingURL=index.d.ts.map