"use strict";
/**
 * User Model
 *
 * CMS user accounts with customer-level access and roles.
 */
Object.defineProperty(exports, "__esModule", { value: true });
//# sourceMappingURL=User.js.map