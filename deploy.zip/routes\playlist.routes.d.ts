/**
 * Playlist Routes
 *
 * API endpoints for playlist management.
 * Playlists are collections of content items that play in sequence.
 */
declare const router: import("express-serve-static-core").Router;
export default router;
//# sourceMappingURL=playlist.routes.d.ts.map