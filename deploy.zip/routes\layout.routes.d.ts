/**
 * Layout Routes
 *
 * API endpoints for layout management.
 */
declare const router: import("express-serve-static-core").Router;
export default router;
//# sourceMappingURL=layout.routes.d.ts.map