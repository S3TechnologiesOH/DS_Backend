/**
 * Swagger/OpenAPI Configuration
 *
 * Configures API documentation using swagger-jsdoc
 * Access documentation at: /api-docs
 */
export declare const swaggerSpec: object;
//# sourceMappingURL=swagger.d.ts.map