"use strict";
/**
 * Player Model
 *
 * Individual screens/devices at sites.
 */
Object.defineProperty(exports, "__esModule", { value: true });
//# sourceMappingURL=Player.js.map