/**
 * Content Routes
 *
 * API endpoints for content management.
 * Demonstrates file upload with multer middleware.
 */
declare const router: import("express-serve-static-core").Router;
export default router;
//# sourceMappingURL=content.routes.d.ts.map