"use strict";
/**
 * Database Connection Pool Management
 *
 * Manages connection pool to Azure SQL Database using mssql.
 */
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.sql = exports.isDatabaseConnected = exports.closeDatabase = exports.getDatabase = exports.initializeDatabase = void 0;
const mssql_1 = __importDefault(require("mssql"));
exports.sql = mssql_1.default;
const database_1 = require("../config/database");
const logger_1 = __importDefault(require("../utils/logger"));
const errors_1 = require("../utils/errors");
let pool = null;
/**
 * Initialize database connection pool with retry logic
 */
const initializeDatabase = async (maxRetries = 5, retryDelay = 3000) => {
    if (pool) {
        logger_1.default.info('Database connection pool already exists');
        return pool;
    }
    let lastError;
    for (let attempt = 1; attempt <= maxRetries; attempt++) {
        try {
            logger_1.default.info(`Initializing database connection pool (attempt ${attempt}/${maxRetries})...`);
            pool = await mssql_1.default.connect(database_1.databaseConfig);
            pool.on('error', (err) => {
                logger_1.default.error('Database pool error', { error: err });
            });
            logger_1.default.info('Database connection pool initialized successfully');
            return pool;
        }
        catch (error) {
            lastError = error;
            logger_1.default.warn(`Database connection attempt ${attempt} failed`, { error });
            if (attempt < maxRetries) {
                logger_1.default.info(`Retrying in ${retryDelay}ms...`);
                await new Promise(resolve => setTimeout(resolve, retryDelay));
                // Exponential backoff: increase delay for next retry
                retryDelay = Math.min(retryDelay * 1.5, 15000);
            }
        }
    }
    logger_1.default.error('Failed to initialize database connection pool after all retries', { error: lastError });
    throw new errors_1.DatabaseError('Failed to connect to database after multiple attempts');
};
exports.initializeDatabase = initializeDatabase;
/**
 * Get existing database connection pool
 */
const getDatabase = () => {
    if (!pool) {
        throw new errors_1.DatabaseError('Database pool not initialized. Call initializeDatabase() first.');
    }
    return pool;
};
exports.getDatabase = getDatabase;
/**
 * Close database connection pool
 */
const closeDatabase = async () => {
    try {
        if (pool) {
            await pool.close();
            pool = null;
            logger_1.default.info('Database connection pool closed');
        }
    }
    catch (error) {
        logger_1.default.error('Error closing database connection pool', { error });
        throw error;
    }
};
exports.closeDatabase = closeDatabase;
/**
 * Check if database is connected
 */
const isDatabaseConnected = () => {
    return pool !== null && pool.connected;
};
exports.isDatabaseConnected = isDatabaseConnected;
//# sourceMappingURL=connection.js.map