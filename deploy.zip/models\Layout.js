"use strict";
/**
 * Layout Models
 *
 * Layouts are the building blocks for creating custom content displays.
 * Each layout contains multiple layers (widgets/zones) that can display
 * different types of content.
 */
Object.defineProperty(exports, "__esModule", { value: true });
//# sourceMappingURL=Layout.js.map