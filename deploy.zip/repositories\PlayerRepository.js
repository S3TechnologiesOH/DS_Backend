"use strict";
/**
 * Player Repository
 *
 * Database operations for Players table.
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.PlayerRepository = void 0;
const BaseRepository_1 = require("./BaseRepository");
const errors_1 = require("../utils/errors");
class PlayerRepository extends BaseRepository_1.BaseRepository {
    /**
     * Find player by ID
     */
    async findById(playerId, customerId) {
        const sql = `
      SELECT
        p.PlayerId as playerId,
        p.SiteId as siteId,
        p.Name as name,
        p.PlayerCode as playerCode,
        p.MacAddress as macAddress,
        p.SerialNumber as serialNumber,
        p.Location as location,
        p.ScreenResolution as screenResolution,
        p.Orientation as orientation,
        p.Status as status,
        p.LastHeartbeat as lastHeartbeat,
        p.IpAddress as ipAddress,
        p.PlayerVersion as playerVersion,
        p.OsVersion as osVersion,
        p.IsActive as isActive,
        p.ActivationCode as activationCode,
        p.ActivatedAt as activatedAt,
        p.CreatedAt as createdAt,
        p.UpdatedAt as updatedAt
      FROM Players p
      INNER JOIN Sites s ON p.SiteId = s.SiteId
      WHERE p.PlayerId = @playerId AND s.CustomerId = @customerId
    `;
        return this.queryOne(sql, { playerId, customerId });
    }
    /**
     * Get all players for a customer
     */
    async findByCustomerId(customerId, options) {
        let sql = `
      SELECT
        p.PlayerId as playerId,
        p.SiteId as siteId,
        p.Name as name,
        p.PlayerCode as playerCode,
        p.MacAddress as macAddress,
        p.SerialNumber as serialNumber,
        p.Location as location,
        p.ScreenResolution as screenResolution,
        p.Orientation as orientation,
        p.Status as status,
        p.LastHeartbeat as lastHeartbeat,
        p.IpAddress as ipAddress,
        p.PlayerVersion as playerVersion,
        p.OsVersion as osVersion,
        p.IsActive as isActive,
        p.ActivationCode as activationCode,
        p.ActivatedAt as activatedAt,
        p.CreatedAt as createdAt,
        p.UpdatedAt as updatedAt
      FROM Players p
      INNER JOIN Sites s ON p.SiteId = s.SiteId
      WHERE s.CustomerId = @customerId
    `;
        const params = { customerId };
        if (options?.siteId) {
            sql += ' AND p.SiteId = @siteId';
            params.siteId = options.siteId;
        }
        if (options?.status) {
            sql += ' AND p.Status = @status';
            params.status = options.status;
        }
        if (options?.search) {
            sql += ' AND (p.Name LIKE @search OR p.PlayerCode LIKE @search OR p.Location LIKE @search)';
            params.search = `%${options.search}%`;
        }
        sql += ' ORDER BY p.Name ASC';
        if (options?.limit) {
            sql += ' OFFSET @offset ROWS FETCH NEXT @limit ROWS ONLY';
            params.offset = options.offset || 0;
            params.limit = options.limit;
        }
        return this.queryMany(sql, params);
    }
    /**
     * Find player by player code (for activation)
     */
    async findByPlayerCode(playerCode) {
        const sql = `
      SELECT
        p.PlayerId as playerId,
        p.SiteId as siteId,
        p.Name as name,
        p.PlayerCode as playerCode,
        p.MacAddress as macAddress,
        p.SerialNumber as serialNumber,
        p.Location as location,
        p.ScreenResolution as screenResolution,
        p.Orientation as orientation,
        p.Status as status,
        p.LastHeartbeat as lastHeartbeat,
        p.IpAddress as ipAddress,
        p.PlayerVersion as playerVersion,
        p.OsVersion as osVersion,
        p.IsActive as isActive,
        p.ActivationCode as activationCode,
        p.ActivatedAt as activatedAt,
        p.CreatedAt as createdAt,
        p.UpdatedAt as updatedAt,
        s.CustomerId as customerId
      FROM Players p
      INNER JOIN Sites s ON p.SiteId = s.SiteId
      WHERE p.PlayerCode = @playerCode
    `;
        return this.queryOne(sql, { playerCode });
    }
    /**
     * Get all players for a site
     */
    async findBySiteId(siteId, customerId) {
        const sql = `
      SELECT
        p.PlayerId as playerId,
        p.SiteId as siteId,
        p.Name as name,
        p.PlayerCode as playerCode,
        p.MacAddress as macAddress,
        p.SerialNumber as serialNumber,
        p.Location as location,
        p.ScreenResolution as screenResolution,
        p.Orientation as orientation,
        p.Status as status,
        p.LastHeartbeat as lastHeartbeat,
        p.IpAddress as ipAddress,
        p.PlayerVersion as playerVersion,
        p.OsVersion as osVersion,
        p.IsActive as isActive,
        p.ActivationCode as activationCode,
        p.ActivatedAt as activatedAt,
        p.CreatedAt as createdAt,
        p.UpdatedAt as updatedAt
      FROM Players p
      INNER JOIN Sites s ON p.SiteId = s.SiteId
      WHERE p.SiteId = @siteId AND s.CustomerId = @customerId
      ORDER BY p.Name ASC
    `;
        return this.queryMany(sql, { siteId, customerId });
    }
    /**
     * Create new player
     */
    async create(data) {
        const sql = `
      INSERT INTO Players (
        SiteId, Name, PlayerCode, MacAddress, SerialNumber, Location,
        ScreenResolution, Orientation
      )
      OUTPUT
        INSERTED.PlayerId as playerId,
        INSERTED.SiteId as siteId,
        INSERTED.Name as name,
        INSERTED.PlayerCode as playerCode,
        INSERTED.MacAddress as macAddress,
        INSERTED.SerialNumber as serialNumber,
        INSERTED.Location as location,
        INSERTED.ScreenResolution as screenResolution,
        INSERTED.Orientation as orientation,
        INSERTED.Status as status,
        INSERTED.LastHeartbeat as lastHeartbeat,
        INSERTED.IpAddress as ipAddress,
        INSERTED.PlayerVersion as playerVersion,
        INSERTED.OsVersion as osVersion,
        INSERTED.IsActive as isActive,
        INSERTED.ActivationCode as activationCode,
        INSERTED.ActivatedAt as activatedAt,
        INSERTED.CreatedAt as createdAt,
        INSERTED.UpdatedAt as updatedAt
      VALUES (
        @siteId, @name, @playerCode, @macAddress, @serialNumber, @location,
        @screenResolution, @orientation
      )
    `;
        return this.insert(sql, {
            siteId: data.siteId,
            name: data.name,
            playerCode: data.playerCode,
            macAddress: data.macAddress || null,
            serialNumber: data.serialNumber || null,
            location: data.location || null,
            screenResolution: data.screenResolution || null,
            orientation: data.orientation || 'Landscape',
        });
    }
    /**
     * Update player
     */
    async update(playerId, customerId, data) {
        const updates = [];
        const params = { playerId };
        if (data.name !== undefined) {
            updates.push('Name = @name');
            params.name = data.name;
        }
        if (data.playerCode !== undefined) {
            updates.push('PlayerCode = @playerCode');
            params.playerCode = data.playerCode;
        }
        if (data.macAddress !== undefined) {
            updates.push('MacAddress = @macAddress');
            params.macAddress = data.macAddress;
        }
        if (data.serialNumber !== undefined) {
            updates.push('SerialNumber = @serialNumber');
            params.serialNumber = data.serialNumber;
        }
        if (data.location !== undefined) {
            updates.push('Location = @location');
            params.location = data.location;
        }
        if (data.screenResolution !== undefined) {
            updates.push('ScreenResolution = @screenResolution');
            params.screenResolution = data.screenResolution;
        }
        if (data.orientation !== undefined) {
            updates.push('Orientation = @orientation');
            params.orientation = data.orientation;
        }
        if (data.status !== undefined) {
            updates.push('Status = @status');
            params.status = data.status;
        }
        if (data.ipAddress !== undefined) {
            updates.push('IpAddress = @ipAddress');
            params.ipAddress = data.ipAddress;
        }
        if (data.playerVersion !== undefined) {
            updates.push('PlayerVersion = @playerVersion');
            params.playerVersion = data.playerVersion;
        }
        if (data.osVersion !== undefined) {
            updates.push('OsVersion = @osVersion');
            params.osVersion = data.osVersion;
        }
        if (data.isActive !== undefined) {
            updates.push('IsActive = @isActive');
            params.isActive = data.isActive;
        }
        if (updates.length === 0) {
            throw new Error('No fields to update');
        }
        updates.push('UpdatedAt = GETUTCDATE()');
        const sql = `
      UPDATE p
      SET ${updates.join(', ')}
      OUTPUT
        INSERTED.PlayerId as playerId,
        INSERTED.SiteId as siteId,
        INSERTED.Name as name,
        INSERTED.PlayerCode as playerCode,
        INSERTED.MacAddress as macAddress,
        INSERTED.SerialNumber as serialNumber,
        INSERTED.Location as location,
        INSERTED.ScreenResolution as screenResolution,
        INSERTED.Orientation as orientation,
        INSERTED.Status as status,
        INSERTED.LastHeartbeat as lastHeartbeat,
        INSERTED.IpAddress as ipAddress,
        INSERTED.PlayerVersion as playerVersion,
        INSERTED.OsVersion as osVersion,
        INSERTED.IsActive as isActive,
        INSERTED.ActivationCode as activationCode,
        INSERTED.ActivatedAt as activatedAt,
        INSERTED.CreatedAt as createdAt,
        INSERTED.UpdatedAt as updatedAt
      FROM Players p
      INNER JOIN Sites s ON p.SiteId = s.SiteId
      WHERE p.PlayerId = @playerId AND s.CustomerId = @customerId
    `;
        params.customerId = customerId;
        const result = await this.insert(sql, params);
        if (!result) {
            throw new errors_1.NotFoundError('Player not found');
        }
        return result;
    }
    /**
     * Update player heartbeat
     */
    async updateHeartbeat(playerId, data) {
        const updates = ['LastHeartbeat = GETUTCDATE()', 'Status = @status', 'UpdatedAt = GETUTCDATE()'];
        const params = { playerId, status: data.status };
        if (data.ipAddress) {
            updates.push('IpAddress = @ipAddress');
            params.ipAddress = data.ipAddress;
        }
        if (data.playerVersion) {
            updates.push('PlayerVersion = @playerVersion');
            params.playerVersion = data.playerVersion;
        }
        if (data.osVersion) {
            updates.push('OsVersion = @osVersion');
            params.osVersion = data.osVersion;
        }
        const sql = `
      UPDATE Players
      SET ${updates.join(', ')}
      WHERE PlayerId = @playerId
    `;
        await this.execute(sql, params);
    }
    /**
     * Delete player
     */
    async delete(playerId, customerId) {
        const sql = `
      DELETE p
      FROM Players p
      INNER JOIN Sites s ON p.SiteId = s.SiteId
      WHERE p.PlayerId = @playerId AND s.CustomerId = @customerId
    `;
        const rowsAffected = await this.execute(sql, { playerId, customerId });
        if (rowsAffected === 0) {
            throw new errors_1.NotFoundError('Player not found');
        }
    }
    /**
     * Count players for a customer
     */
    async countByCustomerId(customerId) {
        const sql = `
      SELECT COUNT(*) as count
      FROM Players p
      INNER JOIN Sites s ON p.SiteId = s.SiteId
      WHERE s.CustomerId = @customerId
    `;
        const result = await this.queryOne(sql, { customerId });
        return result?.count ?? 0;
    }
    /**
     * Check if player code exists
     */
    async playerCodeExists(playerCode, siteId, excludePlayerId) {
        let sql = `
      SELECT COUNT(*) as count
      FROM Players
      WHERE PlayerCode = @playerCode AND SiteId = @siteId
    `;
        const params = { playerCode, siteId };
        if (excludePlayerId) {
            sql += ' AND PlayerId != @excludePlayerId';
            params.excludePlayerId = excludePlayerId;
        }
        const result = await this.queryOne(sql, params);
        return (result?.count ?? 0) > 0;
    }
    /**
     * Generate activation code for player
     */
    async generateActivationCode(playerId, customerId) {
        // Generate 6-character alphanumeric code
        const code = Math.random().toString(36).substring(2, 8).toUpperCase();
        // Set expiration to 24 hours from now
        const expiresAt = new Date(Date.now() + 24 * 60 * 60 * 1000);
        const sql = `
      UPDATE p
      SET
        ActivationCode = @code,
        ActivationCodeExpiresAt = @expiresAt,
        UpdatedAt = GETUTCDATE()
      OUTPUT
        INSERTED.ActivationCode as activationCode,
        INSERTED.ActivationCodeExpiresAt as expiresAt
      FROM Players p
      INNER JOIN Sites s ON p.SiteId = s.SiteId
      WHERE p.PlayerId = @playerId AND s.CustomerId = @customerId
    `;
        const result = await this.insert(sql, {
            playerId,
            customerId,
            code,
            expiresAt,
        });
        if (!result) {
            throw new errors_1.NotFoundError('Player not found');
        }
        return result;
    }
    /**
     * Update activation fields (for player authentication service)
     */
    async updateActivation(playerId, data) {
        const sql = `
      UPDATE Players
      SET ActivatedAt = @activatedAt, UpdatedAt = GETUTCDATE()
      WHERE PlayerId = @playerId
    `;
        await this.execute(sql, {
            playerId,
            activatedAt: data.activatedAt,
        });
    }
}
exports.PlayerRepository = PlayerRepository;
//# sourceMappingURL=PlayerRepository.js.map