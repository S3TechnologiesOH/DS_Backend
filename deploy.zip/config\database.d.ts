/**
 * Database Configuration for Azure SQL Database
 *
 * Provides connection configuration using mssql library.
 */
import { config as SqlConfig } from 'mssql';
export declare const databaseConfig: SqlConfig;
//# sourceMappingURL=database.d.ts.map