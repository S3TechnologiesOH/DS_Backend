/**
 * Schedule Routes
 *
 * API endpoints for schedule management.
 * Schedules determine when and where layouts are played with hierarchical assignment.
 */
declare const router: import("express-serve-static-core").Router;
export default router;
//# sourceMappingURL=schedule.routes.d.ts.map