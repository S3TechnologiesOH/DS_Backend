"use strict";
/**
 * Site Model
 *
 * Physical locations belonging to customers (stores, offices, venues).
 */
Object.defineProperty(exports, "__esModule", { value: true });
//# sourceMappingURL=Site.js.map