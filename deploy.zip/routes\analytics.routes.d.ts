/**
 * Analytics Routes
 *
 * @swagger
 * tags:
 *   name: Analytics
 *   description: Analytics and reporting endpoints
 */
declare const router: import("express-serve-static-core").Router;
export default router;
//# sourceMappingURL=analytics.routes.d.ts.map