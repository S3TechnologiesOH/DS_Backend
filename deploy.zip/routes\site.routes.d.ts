/**
 * Site Routes
 *
 * API endpoints for site management.
 * Sites are physical locations under a customer's organization.
 */
declare const router: import("express-serve-static-core").Router;
export default router;
//# sourceMappingURL=site.routes.d.ts.map