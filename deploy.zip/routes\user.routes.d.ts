/**
 * User Routes
 *
 * @swagger
 * tags:
 *   name: Users
 *   description: User management endpoints
 */
declare const router: import("express-serve-static-core").Router;
export default router;
//# sourceMappingURL=user.routes.d.ts.map