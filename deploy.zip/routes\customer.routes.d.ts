/**
 * Customer Routes
 *
 * API endpoints for customer management.
 * Admin-only operations for managing multi-tenant customers.
 */
declare const router: import("express-serve-static-core").Router;
export default router;
//# sourceMappingURL=customer.routes.d.ts.map