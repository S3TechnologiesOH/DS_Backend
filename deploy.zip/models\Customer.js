"use strict";
/**
 * Customer Model
 *
 * Top-level organizations (clients) in the multi-tenant system.
 */
Object.defineProperty(exports, "__esModule", { value: true });
//# sourceMappingURL=Customer.js.map